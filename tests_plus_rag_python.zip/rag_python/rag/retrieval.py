"""Configurable dense, sparse, or hybrid retrieval with optional reranking."""

from rag_python.rag.embeddings import embed_query
from rag_python.rag.storage.indexing import vector_index
from rag_python.rag.storage.db import get_chunks_with_parent_by_ids, keyword_search
from rag_python.rag.rank_fusion import reciprocal_rank_fusion
from rag_python.rag.reranking import rerank
from rag_python.config import TOP_K


VALID_SEARCH_MODES = {"dense", "sparse", "hybrid"}


def _get_search_mode() -> str:
    from rag_python.config import SEARCH_MODE

    mode = SEARCH_MODE.lower()

    if mode not in VALID_SEARCH_MODES:
        raise ValueError(
            f"Unsupported SEARCH_MODE={mode!r}. "
            f"Expected one of: {sorted(VALID_SEARCH_MODES)}"
        )

    return mode


def retrieve(query: str, top_k: int = TOP_K) -> list[dict]:
    if top_k <= 0:
        return []

    from rag_python.config import (
        RERANK_ENABLED,
        RERANK_CANDIDATE_K,
        RRF_K,
        DENSE_CANDIDATE_K,
        SPARSE_CANDIDATE_K,
    )

    mode = _get_search_mode()
    candidate_k = max(top_k, RERANK_CANDIDATE_K) if RERANK_ENABLED else top_k

    if mode == "dense":
        hits = vector_index.search(embed_query(query), candidate_k)
        score_type = "dense"

    elif mode == "sparse":
        hits = keyword_search(query, candidate_k)
        score_type = "sparse"

    else:
        dense_hits = vector_index.search(
            embed_query(query),
            max(candidate_k, DENSE_CANDIDATE_K),
        )
        sparse_hits = keyword_search(
            query,
            max(candidate_k, SPARSE_CANDIDATE_K),
        )

        hits = reciprocal_rank_fusion(
            dense_hits,
            sparse_hits,
            k=RRF_K,
            top_k=candidate_k,
        )
        score_type = "rrf"

    if not hits:
        return []

    data = get_chunks_with_parent_by_ids(
        [chunk_id for chunk_id, _ in hits]
    )

    results = []

    for rank, (chunk_id, score) in enumerate(hits, start=1):
        chunk = data.get(chunk_id)

        if not chunk:
            continue

        results.append({
            "chunk_id": chunk_id,
            "parent_chunk_id": chunk["parent_chunk_id"],
            "content": chunk["content"],
            "source": chunk["source"],
            "score": score,
            "score_type": score_type,
            "rank": rank,
        })

    if RERANK_ENABLED:
        return rerank(query, results, top_k)

    return results[:top_k]